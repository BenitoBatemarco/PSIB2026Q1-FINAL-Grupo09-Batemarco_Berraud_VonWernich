"""
Genera (una sola vez) todas las caches para que la interfaz abra al instante:

  1. subjects_psd_ica.npz  -> PSD post-ICA por sujeto/condicion (paneles
                              Señal/PSD/Bandas/Topomapas).
  2. group_average.npz     -> promedio grupal (pestana "Todos los sujetos").
  3. ml_model.joblib       -> modelo de Machine Learning entrenado + resultados.

Correr una vez despues de instalar las dependencias:

    python build_cache.py                 # autodetecta la carpeta del dataset
    python build_cache.py "ruta/PSIB_Señales"

El paso 1 corre el pipeline COMPLETO con ICA sobre los 60 registros, asi que
puede tardar ~15-30 min. Los pasos 2 y 3 reutilizan esa cache y son rapidos.
"""
from __future__ import annotations

import os
import sys
import glob
import time
import warnings

warnings.simplefilter("ignore")
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import numpy as np
import mne
mne.set_log_level("ERROR")

from core.pipeline import Analyzer, PSD_CACHE_PATH
from core import io as IO
from core import bands as B
from core import ml as ML

GROUP_NPZ = os.path.join(HERE, "group_average.npz")


def _has_subjects(path):
    return bool(glob.glob(os.path.join(path, "sub-*")))


def detect_root():
    for c in [sys.argv[1] if len(sys.argv) > 1 else None,
              HERE, os.path.dirname(HERE), os.getcwd()]:
        if c and os.path.isdir(c) and _has_subjects(c):
            return c
    return None


def _prog(i, n, s):
    print(f"    {s}  ({i}/{n})", flush=True)


def main():
    root = detect_root()
    if root is None:
        print("No se encontro la carpeta del dataset (sub-XX).")
        sys.exit(1)
    subs = IO.find_subjects(root)
    print(f"Dataset: {root}  ·  {len(subs)} sujetos")
    az = Analyzer(root)

    t0 = time.time()
    print("\n[1/3] PSD post-ICA de todos los registros (paso lento)…")
    az.build_psd_cache(subs, progress=_prog)
    print(f"  -> {PSD_CACHE_PATH}  ({time.time()-t0:.0f} s)")

    print("\n[2/3] Promedio grupal…")
    grand = az.grand_average(subs, progress=_prog)
    store = {"freqs": grand["freqs"],
             "ch": np.array(grand["ch_names"], dtype=object)}
    for c in ("rested", "deprived"):
        if c in grand["psd_db"]:
            store[f"psd_{c}"] = grand["psd_db"][c]
            store[f"n_{c}"] = grand["n"][c]
            for b in B.BANDS:
                store[f"topo_{c}_{b}"] = grand["band_topo"][c][b]
    np.savez_compressed(GROUP_NPZ, **store)
    print(f"  -> {GROUP_NPZ}")

    print("\n[3/3] Entrenamiento del modelo de Machine Learning…")
    df = ML.build_dataset(az, subs, progress=_prog)
    res = ML.train_and_select(df, progress=lambda i, n, m: print(
        f"    modelo {m} ({i}/{n})", flush=True))
    ML.save_results(res)
    print(f"  -> {ML.ML_CACHE_PATH}")
    print("\nComparacion de modelos (AUC out-of-fold):")
    print(res.comparison.round(3).to_string(index=False))
    print(f"\nModelo elegido: {res.best_name}  ·  "
          f"AUC={res.best['auc']:.3f}  acc={res.best['accuracy']:.0%}  "
          f"pareada={res.best['paired_accuracy']:.0%}")
    print(f"\nListo en {time.time()-t0:.0f} s. Ya podes abrir la app "
          f"(python main.py).")


if __name__ == "__main__":
    main()
