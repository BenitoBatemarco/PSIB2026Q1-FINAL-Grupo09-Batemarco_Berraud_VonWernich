# PSIB - Análisis EEG de Privación de Sueño (etapa 2: ICA + Machine Learning)

Aplicación de escritorio (Python + Tkinter) que **replica el paper** y, además,
**clasifica** privación de sueño vs descanso con Machine Learning.

> Xiang, C., Fan, X., Bai, D., Lv, K., & Lei, X. (2024).
> *A resting-state EEG dataset for sleep deprivation.* Scientific Data, 11:427.
> OpenNeuro **ds004902**.

En la **etapa 1** el trabajo se hizo *sin* ICA ni Machine Learning. En esta
**etapa 2** se habilitaron ambas técnicas, así que ahora:

- El preprocesamiento incluye **ICA** (tal como el paper) para eliminar
  artefactos oculares y musculares.
- Se agrega un **sistema de clasificación con Machine Learning** (SD vs NS).

---

## 1. Datos

- **30 sujetos** (`sub-01` … `sub-30`), formato **BIDS**.
- Dos sesiones por sujeto: `ses-1` = **Descansado (Normal Sleep, NS)**,
  `ses-2` = **Privación de sueño (Sleep Deprivation, SD)**. Diseño *within-subject*.
- Se usa solo la tarea **`eyesopen`** (ojos abiertos), formato EEGLAB `.set`+`.fdt`.
- **61 canales** (10-20 extendido), referencia online **FCz**, **500 Hz**, **300 s**.

## 2. Pipeline del paper (replicado con ICA)

| Paso del paper | En esta app |
|---|---|
| Filtro 0.2–45 Hz | Sí (FIR) |
| Epochs de 4 s (75) | Sí |
| Rechazo de epochs con artefactos | Sí (umbral de amplitud pico-pico robusto) |
| Interpolación de canales malos | Sí (z-score de varianza) |
| **ICA** (ocular/muscular) | **Sí** — ICA infomax extendido (como EEGLAB `runica`) + **ICLabel** (mne-icalabel) para clasificar y eliminar automáticamente los componentes "ojo" y "músculo" |
| Re-referencia a promedio | Sí |
| PSD por Welch (Cz) | Sí |
| Potencia absoluta en dB | Sí |
| Media ± DE entre sujetos, NS vs SD | Sí (grand-average) |
| Topografías theta/alpha/beta (Fig. 5) | Sí |

Bandas: **theta (4–8), alpha (8–13), beta (13–30 Hz)**.

### Detalle de la ICA

`core/preprocessing.py` ajusta la ICA sobre una copia filtrada en 1 Hz y
re-referenciada al promedio (requisito de ICLabel). ICLabel rotula cada
componente (cerebro / ojo / músculo / corazón / ruido de línea / ruido de canal
/ otro) y se descartan los rotulados **eye blink** y **muscle artifact** con
confianza ≥ 80%. Si `mne-icalabel` no estuviera instalado, hay un *fallback* por
correlación con canales frontales (EOG) + detección de foco muscular.

## 3. Clasificación con Machine Learning (SD vs NS)

`core/ml.py`. Cada registro (sujeto × condición) = una muestra; 30 sujetos × 2
condiciones = **60 muestras**. Las **features** son potencias espectrales
(por banda × región, canales de la línea media, posteriores, razones y potencia
total) calculadas sobre el EEG **ya limpio con ICA**.

**Validación honesta (clave):** como los dos registros de un mismo sujeto se
parecen, se usa **Leave-One-Subject-Out** (los dos registros del sujeto quedan
fuera del entrenamiento). Todas las métricas son *out-of-fold*.

**Selección del mejor modelo:** se comparan Regresión Logística, **SVM (RBF)**,
Random Forest y Gradient Boosting, y se elige automáticamente el de mayor AUC
out-of-fold. Se reportan AUC, exactitud, exactitud balanceada, **exactitud
pareada** (aprovecha el diseño within-subject), matriz de confusión, curva ROC e
**importancia de variables** (por permutación).

## 4. Instalación

Requiere Python 3.9+. En Windows/macOS Tkinter viene incluido.

```bash
pip install -r requirements.txt
# Linux además: sudo apt install python3-tk
```

## 5. Uso

Solo hay que abrir la app:

```bash
python main.py
# o forzando la carpeta:
python main.py "C:\Users\...\PSIB_Señales"
```

**La primera vez, la app hace todo el precálculo sola, en segundo plano:** al
detectar que faltan las caches, corre el pipeline completo con ICA sobre los 60
registros, calcula el promedio grupal y **entrena el modelo de ML**, mostrando el
progreso en la barra inferior (~15-30 min). Al terminar deja guardados
`subjects_psd_ica.npz`, `group_average.npz` y `ml_model.joblib`, y **en las
siguientes corridas abre al instante**. No hay que ejecutar ningún script aparte.

> Opcional: si preferís generar las caches por adelantado desde la terminal (por
> ejemplo en un servidor), existe `python build_cache.py`, que hace exactamente
> lo mismo. Pero no es necesario: la app lo resuelve sola.

Podés dejar la carpeta `psib_eeg/` **dentro** de `PSIB_Señales` (junto a
`sub-01`, …): el dataset se detecta solo.

## 6. Interfaz (7 pestañas)

Arriba, un selector de sujeto (con flechas ‹ ›). Cambiar el sujeto refresca todo.

1. **Señal (NS vs SD)** — las dos condiciones apiladas, señal filtrada.
2. **PSD** — espectro de Welch en dB, NS y SD superpuestos, bandas sombreadas.
3. **Bandas** — potencia por banda y región, barras NS vs SD.
4. **Topomapas** — réplica de la Fig. 5 (NS / SD) del sujeto.
5. **ICA** — para el sujeto/condición elegidos: qué componentes se eliminaron,
   con su etiqueta (ojo/músculo) y confianza, y las topografías de esos
   componentes.
6. **Todos los sujetos (vs paper)** — promedio de los 30 sujetos: PSD de Cz y
   topomaps grupales, al lado de las Fig. 4 y 5 del paper.
7. **Clasificación (ML)** — tres sub-pestañas:
   - *Desempeño*: modelo elegido, AUC/exactitud out-of-fold, comparación de
     modelos, matriz de confusión y curva ROC.
   - *Importancia de variables*: qué features pesan más.
   - *Por sujeto*: predicción out-of-fold de los dos registros del sujeto
     (probabilidad de SD y acierto).

## 7. Estructura del código

```
psib_eeg/
├── main.py                  Lanzador de la interfaz
├── build_cache.py           Genera las caches (ICA + promedio grupal + modelo ML)
├── requirements.txt
├── core/                    Núcleo de análisis (sin GUI)
│   ├── bands.py             Bandas, regiones, canales representativos
│   ├── io.py                Descubrimiento BIDS + carga tolerante .set/.fdt
│   ├── preprocessing.py     Filtro, epochs, interpolación, ICA (ICLabel), avg-ref
│   ├── spectral.py          PSD Welch, potencia abs/rel, dB
│   ├── topo.py              Topomapas por banda (montaje 10-20)
│   ├── ml.py                Features + comparación de modelos + validación LOSO
│   └── pipeline.py          Orquestador con caché en disco
├── assets/                  Fig. 4 y Fig. 5 del paper (para comparar)
└── gui/                     Interfaz Tkinter (ventana + 7 pestañas + tema)
```

## 8. Notas

- Sin marcadores de eventos (resting-state continuo).
- `sub-01 ses-2 eyesopen` tiene el `.fdt` algo truncado; el loader lo recupera.
- Con 60 muestras y alta variabilidad individual, las métricas de ML deben
  leerse como **exploratorias**; por eso se prioriza la validación por sujeto y
  la exactitud pareada.
