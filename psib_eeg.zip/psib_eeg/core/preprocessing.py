"""
Preprocesamiento de EEG replicando el pipeline del paper (Xiang et al., 2024),
ahora CON ICA (habilitado en la etapa 2 del trabajo).

Pipeline (igual que el paper, EEGLAB -> aqui con MNE):
  1. Filtro pasabanda 0.2 - 45 Hz (FIR).
  2. (Notch opcional 50 Hz; red electrica en China, PowerLineFrequency=50.)
  3. Segmentacion en epochs de 4 s  (-> 75 epochs en 5 min).
  4. Rechazo de epochs con artefactos notables (umbral de amplitud pico-pico
     robusto).  El paper elimina ~1.46 epochs en promedio por registro.
  5. Interpolacion de canales malos (varianza atipica).  El paper interpola
     ~2.39% de los canales.
  6. ICA para eliminar componentes oculares y musculares (el paper usa
     Delorme & Makeig, 2004).  Aqui se replica con ICA infomax extendido
     (mismo algoritmo que EEGLAB runica) + clasificacion automatica de
     componentes con ICLabel (mne-icalabel): se descartan los componentes
     "eye blink" y "muscle artifact".  Si mne-icalabel no esta instalado se usa
     un fallback por EOG frontal + deteccion de foco muscular.
  7. Re-referencia a promedio (average reference).

make_epochs devuelve (epochs, report, ica) para que la interfaz pueda mostrar
que componentes se eliminaron (pestana ICA).
"""
from __future__ import annotations

import warnings
import numpy as np
import mne

from . import bands as B

# Rotulos de ICLabel que consideramos artefacto (se eliminan): ocular y muscular.
ARTIFACT_LABELS = ("eye blink", "muscle artifact")

# Parametros por defecto del pipeline.
DEFAULTS = dict(
    l_freq=0.2,
    h_freq=45.0,
    notch=False,
    notch_freq=50.0,
    epoch_len=4.0,
    reject_p2p_uv=0.0,       # 0 => umbral robusto automatico; >0 => fijo (uV)
    interpolate_bads=True,
    bad_z=4.0,
    ica=True,
    ica_n_components=20,
    ica_max_iter=300,
    ica_random_state=97,
    ica_prob=0.80,
    ica_labels=ARTIFACT_LABELS,
    average_ref=True,
)


def filter_raw(raw, l_freq=0.2, h_freq=45.0, notch=False, notch_freq=50.0):
    """Filtra una copia del Raw. No modifica el original."""
    raw = raw.copy()
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        raw.filter(l_freq=l_freq, h_freq=h_freq, fir_design="firwin",
                   verbose="ERROR")
        if notch:
            raw.notch_filter(freqs=[notch_freq], verbose="ERROR")
    return raw


def detect_bad_channels(epochs, z_thresh=4.0):
    """Canales con varianza atipica (z robusto sobre la varianza media)."""
    data = epochs.get_data()
    var = data.var(axis=2).mean(axis=0)
    med = np.median(var)
    mad = np.median(np.abs(var - med)) + 1e-30
    z = 0.6745 * (var - med) / mad
    return [epochs.ch_names[i] for i in np.where(z > z_thresh)[0]]


def _bad_epoch_mask(epochs, p2p_uv):
    """Mascara de epochs a CONSERVAR segun amplitud pico-pico (umbral robusto)."""
    data = epochs.get_data() * 1e6
    ptp = data.max(axis=2) - data.min(axis=2)
    worst = ptp.max(axis=1)
    if p2p_uv and p2p_uv > 0:
        thr = float(p2p_uv)
    else:
        med = np.median(worst)
        mad = np.median(np.abs(worst - med)) + 1e-30
        thr = med + 6.0 * 1.4826 * mad
    return worst < thr, thr


def _fit_ica(epochs_ica, p):
    """Ajusta ICA infomax extendido (como EEGLAB runica)."""
    ica = mne.preprocessing.ICA(
        n_components=p["ica_n_components"], method="infomax",
        fit_params=dict(extended=True), max_iter=p["ica_max_iter"],
        random_state=p["ica_random_state"])
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        ica.fit(epochs_ica, verbose="ERROR")
    return ica


def _label_iclabel(epochs_ica, ica, p):
    """Rotula componentes con ICLabel y elige los artefactos a eliminar."""
    from mne_icalabel import label_components
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        res = label_components(epochs_ica, ica, method="iclabel")
    labels = list(res["labels"])
    probs = np.asarray(res["y_pred_proba"], dtype=float)
    wanted = set(p["ica_labels"])
    exclude = [i for i, lab in enumerate(labels)
               if lab in wanted and probs[i] >= p["ica_prob"]]
    detail = [{"idx": i, "label": labels[i], "prob": float(probs[i])}
              for i in range(len(labels))]
    return exclude, labels, detail, "iclabel"


def _label_eog_fallback(epochs_ica, ica):
    """
    Respaldo cuando ICLabel no esta disponible. Clasifica los componentes en
    'eye blink' (correlacion con canales frontales, proxy de EOG) y
    'muscle artifact' (foco de alta frecuencia), de forma conservadora para no
    eliminar de mas. Devuelve etiquetas equivalentes a las de ICLabel.
    """
    eye, mus = set(), set()
    frontal = [c for c in ("Fp1", "Fp2", "Fpz", "AF7", "AF8")
               if c in epochs_ica.ch_names]
    for ch in frontal:
        try:
            idx, _ = ica.find_bads_eog(epochs_ica, ch_name=ch, threshold=3.0,
                                       verbose="ERROR")
            eye.update(idx)
        except Exception:
            pass
    try:
        # threshold alto = mas estricto (menos componentes marcados).
        idx, _ = ica.find_bads_muscle(epochs_ica, threshold=0.8,
                                      verbose="ERROR")
        mus.update(idx)
    except Exception:
        pass
    mus -= eye  # si un componente es ocular, no lo contamos tambien como muscular
    labels = []
    for i in range(ica.n_components_):
        if i in eye:
            labels.append("eye blink")
        elif i in mus:
            labels.append("muscle artifact")
        else:
            labels.append("brain")
    exclude = sorted(eye | mus)
    detail = [{"idx": i, "label": labels[i], "prob": float("nan")}
              for i in range(ica.n_components_)]
    return exclude, labels, detail, "heuristico (ojo/musculo)"


def run_ica(epochs, p):
    """
    Ajusta ICA sobre una copia (highpass 1 Hz, avg-ref, requisito de ICLabel),
    clasifica los componentes y devuelve (ica, exclude, labels, detail, metodo).
    No aplica todavia la ICA sobre epochs.
    """
    epochs_ica = epochs.copy()
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        epochs_ica.filter(1.0, None, fir_design="firwin", verbose="ERROR")
        epochs_ica.set_eeg_reference("average", verbose="ERROR")
    ica = _fit_ica(epochs_ica, p)
    try:
        exclude, labels, detail, method = _label_iclabel(epochs_ica, ica, p)
    except Exception as exc:
        import sys
        print("[ICA] ICLabel no disponible -> uso fallback EOG. Motivo:",
              repr(exc), file=sys.stderr)
        exclude, labels, detail, method = _label_eog_fallback(epochs_ica, ica)
    ica.exclude = list(exclude)
    return ica, list(exclude), labels, detail, method


def make_epochs(raw, params=None):
    """
    Aplica el pipeline completo y devuelve (epochs, report, ica).
    report: n_epochs_total, n_rejected, n_kept, bad_channels, p2p_thresh_uv,
            ica_method, ica_n_components, ica_excluded, ica_labels, ica_detail.
    """
    p = dict(DEFAULTS)
    if params:
        p.update(params)

    filt = filter_raw(raw, p["l_freq"], p["h_freq"], p["notch"],
                      p["notch_freq"])
    epochs = mne.make_fixed_length_epochs(
        filt, duration=p["epoch_len"], preload=True, verbose="ERROR")
    n_total = len(epochs)
    report = {"n_epochs_total": n_total, "n_rejected": 0, "n_kept": n_total,
              "bad_channels": [], "p2p_thresh_uv": None, "ica_method": None,
              "ica_n_components": 0, "ica_excluded": [], "ica_labels": [],
              "ica_detail": []}

    keep, thr = _bad_epoch_mask(epochs, p["reject_p2p_uv"])
    report["p2p_thresh_uv"] = float(thr)
    if not keep.all():
        epochs = epochs[np.where(keep)[0]]
    report["n_rejected"] = int((~keep).sum())
    report["n_kept"] = len(epochs)

    if p["interpolate_bads"] and len(epochs) > 0:
        bads = detect_bad_channels(epochs, p["bad_z"])
        if bads:
            epochs.info["bads"] = bads
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                epochs.interpolate_bads(reset_bads=True, verbose="ERROR")
        report["bad_channels"] = bads

    ica = None
    if p["ica"] and len(epochs) > 2:
        ica, exclude, labels, detail, method = run_ica(epochs, p)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            ica.apply(epochs, verbose="ERROR")
        report["ica_method"] = method
        report["ica_n_components"] = int(ica.n_components_)
        report["ica_excluded"] = list(exclude)
        report["ica_labels"] = labels
        report["ica_detail"] = detail

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            epochs.set_eeg_reference("average", verbose="ERROR")

    return epochs, report, ica
