"""
Sistema de clasificacion Privacion de sueno (SD) vs Descansado (NS) con
Machine Learning (etapa 2 del trabajo).

Diseno del problema
-------------------
- Una muestra = un registro (sujeto x condicion).  Con 30 sujetos y 2
  condiciones => 60 muestras.  Clase positiva = SD (privacion).
- Features = potencias espectrales por banda/region/canal calculadas sobre el
  EEG YA PREPROCESADO CON ICA (ver core/preprocessing.py y core/spectral.py).

Validacion honesta (clave con N chico y diseno pareado)
-------------------------------------------------------
Los dos registros de un mismo sujeto son muy parecidos entre si.  Si un registro
de un sujeto cae en train y el otro en test, el modelo "hace trampa".  Por eso
usamos **Leave-One-Subject-Out** (LeaveOneGroupOut agrupando por sujeto): en
cada pliegue, los DOS registros de un sujeto quedan fuera del entrenamiento.
Todas las metricas se calculan sobre predicciones out-of-fold (nunca sobre datos
vistos en entrenamiento).

Seleccion del modelo
--------------------
Se comparan varios clasificadores estandar para datos tabulares chicos
(Regresion Logistica regularizada, SVM-RBF, Random Forest, Gradient Boosting) y
se elige automaticamente el de mejor AUC out-of-fold.  Se reporta ademas
exactitud, exactitud balanceada, matriz de confusion, curva ROC, importancia de
variables (permutacion) y una metrica pareada que aprovecha el diseno
within-subject.
"""
from __future__ import annotations

import os
import numpy as np
import pandas as pd

from . import io as IO
from . import bands as B
from . import spectral as S

NS, SD = "rested", "deprived"
POS_LABEL = SD                      # clase positiva
_APP_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ML_CACHE_PATH = os.path.join(_APP_ROOT, "ml_model.joblib")


# --------------------------------------------------------------------------- #
# 1. Extraccion de features
# --------------------------------------------------------------------------- #
def _mean_over(perch, channels):
    vals = [perch[c] for c in channels if c in perch]
    return float(np.mean(vals)) if vals else np.nan


def record_features(res) -> dict:
    """
    Vector de features de un registro (AnalysisResult ya con ICA).
    Combina potencia por banda x region (absoluta en dB y relativa), canales
    de la linea media (Cz, Pz, Oz), posteriores, razones y potencia total.
    """
    abs_bp = res.band_powers(relative=False)
    rel_bp = res.band_powers(relative=True)
    f = {}

    # Potencia por banda y region (dB absoluto + relativa).
    for band in B.BANDS:
        for region, info in B.REGIONS.items():
            a = _mean_over(abs_bp[band], info["channels"])
            r = _mean_over(rel_bp[band], info["channels"])
            f[f"{band}_{region}_dB"] = 10 * np.log10(max(a, 1e-30))
            f[f"{band}_{region}_rel"] = r

    # Canales clave de la linea media (poco afectados por los ojos).
    for ch in ("Cz", "Pz", "Oz", "Fz"):
        for band in B.BANDS:
            v = abs_bp[band].get(ch, np.nan)
            f[f"{band}_{ch}_dB"] = (10 * np.log10(max(v, 1e-30))
                                    if not np.isnan(v) else np.nan)

    # Posteriores (promedio) y razones espectrales.
    post = B.POSTERIOR_CHANNELS
    pt = _mean_over(abs_bp["theta"], post)
    pa = _mean_over(abs_bp["alpha"], post)
    pb = _mean_over(abs_bp["beta"], post)
    f["post_theta_dB"] = 10 * np.log10(max(pt, 1e-30))
    f["post_alpha_dB"] = 10 * np.log10(max(pa, 1e-30))
    f["post_beta_dB"] = 10 * np.log10(max(pb, 1e-30))
    f["alpha_theta_ratio"] = pa / max(pt, 1e-30)
    f["theta_beta_ratio"] = pt / max(pb, 1e-30)

    # Potencia absoluta total (broadband). El paper: SD >= NS.
    full = (B.SPECTRUM_FMIN, B.SPECTRUM_FMAX)
    bp_full = S.band_power(res.psd, res.freqs, full)   # por canal (uV^2)
    f["total_dB_global"] = 10 * np.log10(max(float(np.mean(bp_full)), 1e-30))
    cz = res.ch_names.index("Cz") if "Cz" in res.ch_names else 0
    f["total_dB_cz"] = 10 * np.log10(max(float(bp_full[cz]), 1e-30))
    return f


def build_dataset(analyzer, subjects, progress=None) -> pd.DataFrame:
    """DataFrame: una fila por (sujeto, condicion) con todas las features."""
    rows = []
    n = len(subjects)
    for i, sub in enumerate(subjects):
        for cond in (NS, SD):
            if IO.set_path(analyzer.root, sub, cond) is None:
                continue
            res = analyzer.analyze(sub, cond)
            row = {"subject": sub, "condition": cond}
            row.update(record_features(res))
            rows.append(row)
        if progress:
            progress(i + 1, n, sub)
    return pd.DataFrame(rows)


def feature_columns(df: pd.DataFrame):
    return [c for c in df.columns if c not in ("subject", "condition")]


# --------------------------------------------------------------------------- #
# 2. Modelos candidatos
# --------------------------------------------------------------------------- #
def candidate_models():
    """Diccionario nombre -> pipeline sklearn. Import perezoso de sklearn."""
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import StandardScaler
    from sklearn.impute import SimpleImputer
    from sklearn.linear_model import LogisticRegression
    from sklearn.svm import SVC
    from sklearn.ensemble import (RandomForestClassifier,
                                  GradientBoostingClassifier)

    def scaled(est):
        return Pipeline([
            ("imp", SimpleImputer(strategy="median")),
            ("sc", StandardScaler()),
            ("clf", est)])

    def tree(est):
        return Pipeline([
            ("imp", SimpleImputer(strategy="median")),
            ("clf", est)])

    return {
        "Regresion Logistica": scaled(
            LogisticRegression(C=0.5, max_iter=2000, class_weight="balanced")),
        "SVM (RBF)": scaled(
            SVC(kernel="rbf", C=1.0, gamma="scale", probability=True,
                class_weight="balanced", random_state=0)),
        "Random Forest": tree(
            RandomForestClassifier(n_estimators=200, max_depth=4,
                                   min_samples_leaf=3, class_weight="balanced",
                                   random_state=0, n_jobs=1)),
        "Gradient Boosting": tree(
            GradientBoostingClassifier(n_estimators=200, max_depth=2,
                                       learning_rate=0.05, random_state=0)),
    }


# --------------------------------------------------------------------------- #
# 3. Evaluacion Leave-One-Subject-Out
# --------------------------------------------------------------------------- #
def _pos_col(clf, classes):
    """Indice de la columna de probabilidad de la clase positiva (SD)."""
    classes = list(classes)
    return classes.index(POS_LABEL) if POS_LABEL in classes else 1


def evaluate_model(model, X, y, groups):
    """
    Predicciones out-of-fold con LeaveOneSubjectOut. Devuelve dict con proba
    de SD, prediccion, y metricas (acc, balanced acc, AUC).
    """
    from sklearn.model_selection import LeaveOneGroupOut, cross_val_predict
    from sklearn.metrics import (accuracy_score, balanced_accuracy_score,
                                 roc_auc_score)
    logo = LeaveOneGroupOut()
    proba = cross_val_predict(model, X, y, cv=logo, groups=groups,
                              method="predict_proba", n_jobs=1)
    # Determinar columna de SD usando las clases del estimador.
    model.fit(X, y)
    j = _pos_col(model, model.classes_)
    p_sd = proba[:, j]
    pred = np.where(p_sd >= 0.5, SD, NS)
    y_bin = (np.asarray(y) == SD).astype(int)
    return {
        "proba_sd": p_sd,
        "pred": pred,
        "accuracy": float(accuracy_score(y, pred)),
        "balanced_accuracy": float(balanced_accuracy_score(y, pred)),
        "auc": float(roc_auc_score(y_bin, p_sd)),
    }


def paired_accuracy(df, subjects_arr, proba_sd):
    """
    Exactitud pareada (aprovecha el diseno within-subject): para cada sujeto,
    se acierta si la proba de SD de su registro SD supera la de su registro NS.
    """
    ok = tot = 0
    d = pd.DataFrame({"subject": subjects_arr,
                      "condition": df["condition"].values, "p": proba_sd})
    for sub, g in d.groupby("subject"):
        if set(g["condition"]) >= {NS, SD}:
            p_ns = g.loc[g.condition == NS, "p"].iloc[0]
            p_sd = g.loc[g.condition == SD, "p"].iloc[0]
            ok += int(p_sd > p_ns)
            tot += 1
    return (ok / tot) if tot else np.nan, ok, tot


# --------------------------------------------------------------------------- #
# 4. Resultado empaquetado
# --------------------------------------------------------------------------- #
class MLResults:
    """Contenedor (picklable) con todo lo necesario para la interfaz."""
    def __init__(self, **kw):
        self.__dict__.update(kw)


def _confusion(y_true, y_pred):
    from sklearn.metrics import confusion_matrix
    return confusion_matrix(y_true, y_pred, labels=[NS, SD])


def _roc_curve(y_true, p_sd):
    from sklearn.metrics import roc_curve
    y_bin = (np.asarray(y_true) == SD).astype(int)
    fpr, tpr, _ = roc_curve(y_bin, p_sd)
    return fpr, tpr


def _permutation_importance(model, X, y, feats):
    from sklearn.inspection import permutation_importance
    model.fit(X, y)
    r = permutation_importance(model, X, y, n_repeats=20, random_state=0,
                               scoring="balanced_accuracy", n_jobs=1)
    imp = pd.DataFrame({"feature": feats,
                        "importance": r.importances_mean,
                        "std": r.importances_std})
    return imp.sort_values("importance", ascending=False).reset_index(drop=True)


def train_and_select(df: pd.DataFrame, progress=None) -> MLResults:
    """
    Entrena y compara los modelos, elige el mejor por AUC out-of-fold y arma el
    objeto de resultados. `df` viene de build_dataset().
    """
    feats = feature_columns(df)
    X = df[feats].values
    y = df["condition"].values
    groups = df["subject"].values

    models = candidate_models()
    comparison = []
    per_model = {}
    n = len(models)
    for i, (name, model) in enumerate(models.items()):
        ev = evaluate_model(model, X, y, groups)
        pa, pok, ptot = paired_accuracy(df, groups, ev["proba_sd"])
        ev["paired_accuracy"] = pa
        ev["paired_ok"] = pok
        ev["paired_tot"] = ptot
        per_model[name] = ev
        comparison.append({"model": name, "auc": ev["auc"],
                           "accuracy": ev["accuracy"],
                           "balanced_accuracy": ev["balanced_accuracy"],
                           "paired_accuracy": pa})
        if progress:
            progress(i + 1, n, name)
    comp_df = (pd.DataFrame(comparison)
               .sort_values(["auc", "accuracy"], ascending=False)
               .reset_index(drop=True))
    best_name = comp_df.iloc[0]["model"]
    best_ev = per_model[best_name]

    # Modelo final entrenado con TODOS los datos + importancias.
    final_model = candidate_models()[best_name]
    final_model.fit(X, y)
    importances = _permutation_importance(candidate_models()[best_name],
                                          X, y, feats)

    # Tabla de predicciones out-of-fold por registro.
    pred_df = pd.DataFrame({
        "subject": groups, "condition": y,
        "proba_sd": best_ev["proba_sd"], "pred": best_ev["pred"],
        "correct": best_ev["pred"] == y})

    return MLResults(
        features=feats, comparison=comp_df, best_name=best_name,
        best=best_ev, per_model=per_model, predictions=pred_df,
        importances=importances,
        confusion=_confusion(y, best_ev["pred"]),
        roc=_roc_curve(y, best_ev["proba_sd"]),
        final_model=final_model, n_records=len(df),
        n_subjects=int(df["subject"].nunique()))


# --------------------------------------------------------------------------- #
# 5. Persistencia
# --------------------------------------------------------------------------- #
def save_results(results: MLResults, path=ML_CACHE_PATH):
    import joblib
    joblib.dump(results, path)
    return path


def load_results(path=ML_CACHE_PATH):
    if not os.path.exists(path):
        return None
    try:
        import joblib
        return joblib.load(path)
    except Exception:
        return None


# --------------------------------------------------------------------------- #
# 6. Etiquetas legibles de features (para la interfaz)
# --------------------------------------------------------------------------- #
def feature_label(feat: str) -> str:
    parts = feat.split("_")
    band = parts[0].capitalize()
    if feat.startswith("total_dB"):
        return "Potencia total " + ("(Cz)" if "cz" in feat else "(global)")
    if feat.endswith("_dB"):
        mid = "_".join(parts[1:-1])
        return f"{band} · {mid} (dB)"
    if feat.endswith("_rel"):
        mid = "_".join(parts[1:-1])
        return f"{band} · {mid} (rel.)"
    if "ratio" in feat:
        return feat.replace("_", " ")
    return feat
