"""
Orquestador del analisis: une carga, preprocesamiento (con ICA) y espectro,
con cache en memoria y en disco. Lo usan la GUI y los scripts.

Dos rutas de calculo:
  - analyze(): ruta rapida para los paneles espectrales. Usa la cache de PSD en
    disco (subjects_psd_ica.npz) si existe; si no, corre el pipeline COMPLETO
    (incluida la ICA) y guarda el resultado en memoria.
  - preprocess_full(): siempre corre el pipeline completo y ademas conserva el
    objeto ICA y los epochs, para la pestana de ICA.

La cache de PSD lleva el sufijo "_ica" para no confundirla con la de la etapa 1
(que se calculo SIN ICA y por lo tanto ya no es valida).
"""
from __future__ import annotations

import os
import numpy as np
import pandas as pd

from . import io as IO
from . import preprocessing as PP
from . import spectral as S
from . import bands as B

_APP_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PSD_CACHE_PATH = os.path.join(_APP_ROOT, "subjects_psd_ica.npz")


def _load_psd_cache():
    if not os.path.exists(PSD_CACHE_PATH):
        return None
    try:
        z = np.load(PSD_CACHE_PATH, allow_pickle=True)
        ch = [str(c) for c in z["ch"]]
        freqs = z["freqs"]
        data = {k: z[k] for k in z.files if "__" in k}
        return {"freqs": freqs, "ch": ch, "data": data}
    except Exception:
        return None


class AnalysisResult:
    """Resultado de analizar un (sujeto, condicion)."""
    def __init__(self, subject, condition, epochs, report, psd, freqs,
                 ch_names, ica=None):
        self.subject = subject
        self.condition = condition
        self.epochs = epochs
        self.report = report
        self.psd = psd
        self.freqs = freqs
        self.ch_names = ch_names
        self.ica = ica

    def band_powers(self, relative=False, band_dict=None):
        return S.all_band_powers(self.psd, self.freqs, self.ch_names,
                                 band_dict=band_dict, relative=relative)

    def channel_psd_db(self, channel):
        if channel not in self.ch_names:
            return None
        idx = self.ch_names.index(channel)
        return S.to_db(self.psd[idx])


class Analyzer:
    """Carga y analiza registros, cacheando por (sujeto, condicion)."""

    def __init__(self, root, params=None):
        self.root = root
        self.params = dict(PP.DEFAULTS)
        if params:
            self.params.update(params)
        self._cache = {}
        self._full = {}
        self._disk = _load_psd_cache()

    def set_params(self, params):
        self.params.update(params)
        self._cache.clear()
        self._full.clear()
        self._disk = None

    def _from_disk(self, subject, condition):
        if not self._disk:
            return None
        psd = self._disk["data"].get(f"{subject}__{condition}")
        if psd is None:
            return None
        return AnalysisResult(subject, condition, None, {"cached": True},
                              np.asarray(psd, dtype=float),
                              self._disk["freqs"], list(self._disk["ch"]))

    def preprocess_full(self, subject, condition, force=False):
        """Corre SIEMPRE el pipeline completo (con ICA) y conserva ICA/epochs."""
        key = (subject, condition)
        if not force and key in self._full:
            return self._full[key]
        raw = IO.load_raw(self.root, subject, condition, preload=True)
        epochs, report, ica = PP.make_epochs(raw, self.params)
        psd, freqs, ch_names = S.compute_psd(epochs)
        res = AnalysisResult(subject, condition, epochs, report, psd, freqs,
                             ch_names, ica=ica)
        self._full[key] = res
        self._cache[key] = res
        return res

    def analyze(self, subject, condition, force=False):
        key = (subject, condition)
        if not force and key in self._cache:
            return self._cache[key]
        if not force:
            cached = self._from_disk(subject, condition)
            if cached is not None:
                self._cache[key] = cached
                return cached
        return self.preprocess_full(subject, condition, force=force)

    def collect_band_power(self, subjects, channels=None, relative=False,
                           band_dict=None, progress=None):
        if band_dict is None:
            band_dict = B.BANDS
        if channels is None:
            channels = B.REPRESENTATIVE_CHANNELS
        rows = []
        n = len(subjects)
        for i, sub in enumerate(subjects):
            for cond in B.CONDITIONS:
                if IO.set_path(self.root, sub, cond) is None:
                    continue
                res = self.analyze(sub, cond)
                bp = res.band_powers(relative=relative, band_dict=band_dict)
                for band, perch in bp.items():
                    for ch in channels:
                        if ch in perch:
                            rows.append(dict(subject=sub, condition=cond,
                                             band=band, channel=ch,
                                             power=perch[ch]))
            if progress:
                progress(i + 1, n, sub)
        return pd.DataFrame(rows)

    def collect_region_power(self, subjects, relative=False, band_dict=None,
                             progress=None):
        if band_dict is None:
            band_dict = B.BANDS
        rows = []
        n = len(subjects)
        for i, sub in enumerate(subjects):
            for cond in B.CONDITIONS:
                if IO.set_path(self.root, sub, cond) is None:
                    continue
                res = self.analyze(sub, cond)
                bp = res.band_powers(relative=relative, band_dict=band_dict)
                reg = S.region_band_power(bp)
                for band, perreg in reg.items():
                    for region, val in perreg.items():
                        rows.append(dict(subject=sub, condition=cond,
                                         band=band, region=region, power=val))
            if progress:
                progress(i + 1, n, sub)
        return pd.DataFrame(rows)

    def grand_psd(self, subjects, condition, progress=None):
        psds, freqs_ref, ch_ref = [], None, None
        n = len(subjects)
        for i, sub in enumerate(subjects):
            if IO.set_path(self.root, sub, condition) is None:
                continue
            res = self.analyze(sub, condition)
            if freqs_ref is None:
                freqs_ref, ch_ref = res.freqs, res.ch_names
            psds.append(S.to_db(res.psd))
            if progress:
                progress(i + 1, n, sub)
        if not psds:
            return None
        arr = np.stack(psds)
        return arr.mean(0), arr.std(0) / np.sqrt(arr.shape[0]), freqs_ref, ch_ref

    def grand_average(self, subjects, progress=None):
        from . import topo as TP
        conds = list(B.CONDITIONS)
        acc_psd = {c: [] for c in conds}
        acc_topo = {c: {b: [] for b in B.BANDS} for c in conds}
        freqs_ref, ch_ref = None, None
        n = len(subjects)
        for i, sub in enumerate(subjects):
            for cond in conds:
                if IO.set_path(self.root, sub, cond) is None:
                    continue
                res = self.analyze(sub, cond)
                if freqs_ref is None:
                    freqs_ref, ch_ref = res.freqs, res.ch_names
                acc_psd[cond].append(S.to_db(res.psd))
                for band in B.BANDS:
                    tvals, _ = TP.band_topo_values(res.psd, res.freqs,
                                                   res.ch_names, B.BANDS[band],
                                                   in_db=True)
                    acc_topo[cond][band].append(tvals)
            if progress:
                progress(i + 1, n, sub)
        out = {"freqs": freqs_ref, "ch_names": ch_ref,
               "psd_db": {}, "band_topo": {}, "n": {}}
        for cond in conds:
            if acc_psd[cond]:
                out["psd_db"][cond] = np.mean(np.stack(acc_psd[cond]), axis=0)
                out["n"][cond] = len(acc_psd[cond])
                out["band_topo"][cond] = {
                    b: np.mean(np.stack(acc_topo[cond][b]), axis=0)
                    for b in B.BANDS}
        return out

    def build_psd_cache(self, subjects, path=PSD_CACHE_PATH, progress=None):
        """Corre el pipeline completo (con ICA) para todos y guarda el PSD."""
        store = {}
        freqs_ref, ch_ref = None, None
        n = len(subjects)
        for i, sub in enumerate(subjects):
            for cond in B.CONDITIONS:
                if IO.set_path(self.root, sub, cond) is None:
                    continue
                res = self.preprocess_full(sub, cond)
                if freqs_ref is None:
                    freqs_ref, ch_ref = res.freqs, res.ch_names
                store[f"{sub}__{cond}"] = res.psd.astype(np.float32)
                self._full.pop((sub, cond), None)
            if progress:
                progress(i + 1, n, sub)
        if freqs_ref is None:
            return None
        np.savez_compressed(path, freqs=freqs_ref,
                            ch=np.array(ch_ref, dtype=object), **store)
        self._disk = _load_psd_cache()
        return path
