# -*- coding: utf-8 -*-
"""
Pestana "ICA": muestra la limpieza por Analisis de Componentes Independientes
que se aplica en el preprocesamiento (replica del paper, etapa 2).

Para el sujeto y la condicion elegidos:
  - Corre el pipeline COMPLETO (con ICA) en segundo plano.
  - Resume el metodo (ICLabel), cuantos componentes se ajustaron y cuales se
    eliminaron, con su etiqueta (ojo / musculo) y confianza.
  - Dibuja las topografias de los componentes eliminados.
"""
from __future__ import annotations

import tkinter as tk
from tkinter import ttk
import warnings
import numpy as np

from ..widgets import MplCanvas
from .. import theme as TH


class IcaPanel(ttk.Frame):
    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        self.cond_var = tk.StringVar(value="rested")
        self._build()

    def _build(self):
        head = ttk.Frame(self)
        head.pack(fill=tk.X, padx=18, pady=(16, 8))
        col = ttk.Frame(head)
        col.pack(side=tk.LEFT)
        ttk.Label(col, text="Limpieza con ICA",
                  style="H1.TLabel").pack(anchor="w")
        ttk.Label(col, text="ICA infomax + ICLabel elimina automaticamente los "
                  "componentes oculares y musculares (como el paper).",
                  style="Muted.TLabel").pack(anchor="w", pady=(2, 0))
        rcol = ttk.Frame(head)
        rcol.pack(side=tk.RIGHT)
        for val, txt in (("rested", "NS · Descansado"),
                         ("deprived", "SD · Privación")):
            ttk.Radiobutton(rcol, text=txt, value=val, variable=self.cond_var,
                            command=self.refresh).pack(side=tk.LEFT, padx=6)
        TH.hsep(self).pack(fill=tk.X, padx=18)

        body = ttk.Frame(self, style="Card.TFrame")
        body.pack(fill=tk.BOTH, expand=True, padx=18, pady=(8, 14))

        self.summary = tk.Label(body, text="", font=TH.F_BODY, bg=TH.SURFACE_ALT,
                                fg=TH.TEXT, justify="left", anchor="nw",
                                padx=16, pady=14, wraplength=320)
        self.summary.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))

        self.canvas = MplCanvas(body, figsize=(7.5, 5.2))
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    # ------------------------------------------------------------------ #
    def refresh(self, *_):
        if self.app.analyzer is None or self.app.current_subject is None:
            return
        cond = self.cond_var.get()
        if not self.app.has_condition(cond):
            self.summary.config(text="Este sujeto no tiene esa condición.")
            self.canvas.clear()
            self.canvas.draw()
            return
        sub = self.app.current_subject
        az = self.app.analyzer
        self.summary.config(text="Calculando ICA…  (puede tardar ~20 s)")
        self.canvas.clear()
        self.canvas.draw()

        def job(progress):
            return az.preprocess_full(sub, cond)

        self.app.worker.run(job, on_done=self._render,
                            on_error=lambda e, tb: self.summary.config(
                                text=f"Error: {e}"))

    def _render(self, res):
        rep = res.report
        detail = rep.get("ica_detail", [])
        excluded = set(rep.get("ica_excluded", []))
        method = rep.get("ica_method", "?")
        ncomp = rep.get("ica_n_components", 0)

        # Resumen de texto.
        lines = [f"Método:  {method}",
                 f"Componentes ICA:  {ncomp}",
                 f"Epochs conservados:  {rep.get('n_kept', '?')} / "
                 f"{rep.get('n_epochs_total', '?')}"]
        bads = rep.get("bad_channels", [])
        lines.append(f"Canales interpolados:  "
                     f"{', '.join(bads) if bads else 'ninguno'}")
        lines.append("")
        if excluded:
            lines.append(f"Componentes ELIMINADOS ({len(excluded)}):")
            for d in detail:
                if d["idx"] in excluded:
                    prob = ("" if np.isnan(d["prob"])
                            else f"  ({d['prob']*100:.0f}%)")
                    lines.append(f"   • IC{d['idx']:02d}  {d['label']}{prob}")
        else:
            lines.append("No se eliminaron componentes\n(sin artefactos "
                         "oculares/musculares claros).")
        self.summary.config(text="\n".join(lines))

        # Topografias de los componentes eliminados.
        self.canvas.clear()
        fig = self.canvas.figure
        ica = res.ica
        idxs = sorted(excluded)
        if ica is None or not idxs:
            ax = fig.add_subplot(111)
            ax.axis("off")
            ax.text(0.5, 0.5, "Sin componentes eliminados para mostrar",
                    ha="center", va="center", color=TH.TEXT_MUTED)
            self.canvas.draw()
            return
        try:
            maps = ica.get_components()          # (n_ch, n_comp)
            info = ica.info
            import mne
            n = len(idxs)
            cols = min(4, n)
            rows = int(np.ceil(n / cols))
            axes = fig.subplots(rows, cols, squeeze=False)
            for k, comp in enumerate(idxs):
                ax = axes[k // cols][k % cols]
                ax.grid(False)
                lab = next((d["label"] for d in detail if d["idx"] == comp), "")
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    mne.viz.plot_topomap(maps[:, comp], info, axes=ax,
                                         show=False, contours=4)
                ax.set_title(f"IC{comp:02d}\n{lab}", fontsize=9)
            for k in range(n, rows * cols):
                axes[k // cols][k % cols].axis("off")
            fig.suptitle(f"{res.subject} · componentes eliminados",
                         fontsize=11, fontweight="bold")
        except Exception as exc:  # noqa
            ax = fig.add_subplot(111)
            ax.axis("off")
            ax.text(0.5, 0.5, f"No se pudieron dibujar los mapas\n{exc}",
                    ha="center", va="center", color=TH.TEXT_MUTED)
        self.canvas.draw()
