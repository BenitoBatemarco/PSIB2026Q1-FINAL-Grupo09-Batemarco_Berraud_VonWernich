# -*- coding: utf-8 -*-
"""
Pestana "Clasificacion (ML)": sistema de Machine Learning que distingue
Privacion de sueno (SD) vs Descansado (NS).  Tres subpestanas:

  A) Desempeno   - modelo elegido, metricas out-of-fold (AUC, exactitud,
                   exactitud pareada), comparacion de modelos, matriz de
                   confusion y curva ROC.
  B) Importancia - que variables (features) pesan mas en la decision.
  C) Por sujeto  - prediccion out-of-fold de los dos registros del sujeto
                   actual (probabilidad de SD y acierto).

Toda la validacion es Leave-One-Subject-Out (sin fuga de datos).  Ver core/ml.py.
"""
from __future__ import annotations

import tkinter as tk
from tkinter import ttk
import numpy as np

from ..widgets import MplCanvas
from .. import theme as TH
from core import ml as ML


# =========================================================================== #
class MLPanel(ttk.Frame):
    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        head = ttk.Frame(self)
        head.pack(fill=tk.X, padx=18, pady=(16, 6))
        ttk.Label(head, text="Clasificación con Machine Learning",
                  style="H1.TLabel").pack(anchor="w")
        ttk.Label(head, text="Privación de sueño (SD) vs descansado (NS).  "
                  "Validación dejando un sujeto afuera.",
                  style="Muted.TLabel").pack(anchor="w", pady=(2, 0))

        self.subnb = ttk.Notebook(self)
        self.subnb.pack(fill=tk.BOTH, expand=True, padx=12, pady=(6, 10))
        self.perf = PerformancePanel(self.subnb, app)
        self.imp = ImportancePanel(self.subnb, app)
        self.subj = SubjectMLPanel(self.subnb, app)
        self.subpanels = [self.perf, self.imp, self.subj]
        self.subnb.add(self.perf, text="   Desempeño   ")
        self.subnb.add(self.imp, text="   Importancia de variables   ")
        self.subnb.add(self.subj, text="   Por sujeto   ")
        self.subnb.bind("<<NotebookTabChanged>>", lambda e: self._show())

    def refresh(self, *_):
        if self.app.analyzer is None:
            return
        if getattr(self.app, "ml_results", None) is None:
            self.perf.set_busy("Entrenando modelos… (primera vez puede tardar)")
            self.app.ensure_ml(self._show)
        else:
            self._show()

    def _show(self):
        if getattr(self.app, "ml_results", None) is None:
            return
        idx = self.subnb.index(self.subnb.select())
        self.subpanels[idx].refresh()


def _kpi(parent, value, label, color):
    f = tk.Frame(parent, bg=TH.SURFACE_ALT)
    tk.Label(f, text=value, font=(TH.FAMILY, 26, "bold"), bg=TH.SURFACE_ALT,
             fg=color).pack(anchor="w", padx=18, pady=(14, 0))
    tk.Label(f, text=label, font=TH.F_SMALL, bg=TH.SURFACE_ALT,
             fg=TH.TEXT_MUTED).pack(anchor="w", padx=18, pady=(0, 14))
    return f


# =========================================================================== #
class PerformancePanel(ttk.Frame):
    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        self.top = tk.Frame(self, bg=TH.SURFACE)
        self.top.pack(fill=tk.X, padx=16, pady=(12, 4))
        self.kpis = tk.Frame(self, bg=TH.SURFACE)
        self.kpis.pack(fill=tk.X, padx=16, pady=6)
        self.canvas = MplCanvas(self, figsize=(8.5, 3.9))
        self.canvas.pack(fill=tk.BOTH, expand=True, padx=16, pady=(4, 12))
        self._msg = None

    def set_busy(self, text):
        for w in self.top.winfo_children():
            w.destroy()
        self._msg = tk.Label(self.top, text=text, font=TH.F_BODY,
                             bg=TH.SURFACE, fg=TH.TEXT_MUTED)
        self._msg.pack(anchor="w")

    def refresh(self, *_):
        r = self.app.ml_results
        if r is None:
            return
        for w in self.top.winfo_children():
            w.destroy()
        for w in self.kpis.winfo_children():
            w.destroy()
        tk.Label(self.top, text=f"Modelo elegido:  {r.best_name}",
                 font=TH.F_H2, bg=TH.SURFACE, fg=TH.PRIMARY_DARK).pack(
            side=tk.LEFT)
        tk.Label(self.top, text=f"   ·   {r.n_records} registros · "
                 f"{r.n_subjects} sujetos", font=TH.F_SMALL, bg=TH.SURFACE,
                 fg=TH.TEXT_MUTED).pack(side=tk.LEFT)

        b = r.best
        _kpi(self.kpis, f"{b['auc']:.2f}", "AUC (out-of-fold)",
             TH.PRIMARY).pack(side=tk.LEFT, expand=True, fill=tk.X, padx=4)
        _kpi(self.kpis, f"{b['accuracy']:.0%}", "Exactitud",
             TH.SUCCESS).pack(side=tk.LEFT, expand=True, fill=tk.X, padx=4)
        pa = b.get("paired_accuracy", float("nan"))
        _kpi(self.kpis, "—" if np.isnan(pa) else f"{pa:.0%}",
             f"Pareada ({b.get('paired_ok','?')}/{b.get('paired_tot','?')})",
             TH.SD).pack(side=tk.LEFT, expand=True, fill=tk.X, padx=4)

        self.canvas.clear()
        fig = self.canvas.figure
        ax1, ax2, ax3 = fig.subplots(1, 3)

        # Comparacion de modelos (AUC).
        comp = r.comparison
        ax1.grid(False)
        y = np.arange(len(comp))
        ax1.barh(y, comp["auc"].values, color=TH.PRIMARY)
        ax1.set_yticks(y)
        ax1.set_yticklabels(comp["model"].values, fontsize=7)
        ax1.invert_yaxis()
        ax1.set_xlim(0, 1)
        ax1.axvline(0.5, color=TH.TEXT_MUTED, ls="--", lw=1)
        ax1.set_title("AUC por modelo")

        # Matriz de confusion.
        cm = np.asarray(r.confusion)
        ax2.imshow(cm, cmap="Blues")
        ax2.set_xticks([0, 1]); ax2.set_yticks([0, 1])
        ax2.set_xticklabels(["NS", "SD"]); ax2.set_yticklabels(["NS", "SD"])
        ax2.set_xlabel("Predicho"); ax2.set_ylabel("Real")
        ax2.set_title("Matriz de confusión")
        ax2.grid(False)
        for i in range(2):
            for j in range(2):
                ax2.text(j, i, str(cm[i, j]), ha="center", va="center",
                         color="white" if cm[i, j] > cm.max() / 2 else TH.TEXT,
                         fontsize=13, fontweight="bold")

        # Curva ROC.
        fpr, tpr = r.roc
        ax3.plot(fpr, tpr, color=TH.SD, lw=2)
        ax3.plot([0, 1], [0, 1], color=TH.TEXT_MUTED, ls="--", lw=1)
        ax3.set_xlabel("FPR"); ax3.set_ylabel("TPR")
        ax3.set_title(f"ROC (AUC={b['auc']:.2f})")
        fig.tight_layout()
        self.canvas.draw()


# =========================================================================== #
class ImportancePanel(ttk.Frame):
    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        tk.Label(self, text="Importancia por permutación (caída de AUC al "
                 "desordenar cada variable)", font=TH.F_SMALL, bg=TH.SURFACE,
                 fg=TH.TEXT_MUTED).pack(anchor="w", padx=18, pady=(12, 0))
        self.canvas = MplCanvas(self, figsize=(8.5, 5.2))
        self.canvas.pack(fill=tk.BOTH, expand=True, padx=16, pady=(4, 12))

    def refresh(self, *_):
        r = self.app.ml_results
        if r is None:
            return
        imp = r.importances.head(15).iloc[::-1]
        self.canvas.clear()
        ax = self.canvas.figure.add_subplot(111)
        ax.grid(False)
        y = np.arange(len(imp))
        ax.barh(y, imp["importance"].values, xerr=imp["std"].values,
                color=TH.PRIMARY, ecolor=TH.BORDER)
        ax.set_yticks(y)
        ax.set_yticklabels([ML.feature_label(f) for f in imp["feature"]],
                           fontsize=8)
        ax.set_xlabel("Importancia (Δ AUC)")
        ax.set_title("Variables más informativas")
        self.canvas.figure.tight_layout()
        self.canvas.draw()


# =========================================================================== #
class SubjectMLPanel(ttk.Frame):
    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        self.wrap = tk.Frame(self, bg=TH.SURFACE)
        self.wrap.pack(fill=tk.BOTH, expand=True, padx=20, pady=16)
        tk.Label(self.wrap, text="Predicción del modelo para este sujeto",
                 font=TH.F_H1, bg=TH.SURFACE, fg=TH.TEXT).pack(anchor="w")
        tk.Label(self.wrap, text="Probabilidad de privación (SD) estimada "
                 "out-of-fold: el sujeto no participó del entrenamiento.",
                 font=TH.F_SMALL, bg=TH.SURFACE, fg=TH.TEXT_MUTED).pack(
            anchor="w", pady=(2, 12))
        self.total = tk.Label(self.wrap, text="", font=(TH.FAMILY, 12, "bold"),
                              bg=TH.PRIMARY_LIGHT, fg=TH.PRIMARY_DARK,
                              padx=14, pady=10, anchor="w", justify="left")
        self.total.pack(fill=tk.X, pady=(0, 12))
        self.rows = tk.Frame(self.wrap, bg=TH.SURFACE)
        self.rows.pack(fill=tk.X)

    def _row(self, real_label, proba_sd, pred, correct):
        card = tk.Frame(self.rows, bg=TH.SURFACE_ALT)
        card.pack(fill=tk.X, pady=6)
        inner = tk.Frame(card, bg=TH.SURFACE_ALT)
        inner.pack(fill=tk.X, padx=18, pady=14)
        name = ("Señal de DESCANSO  (real: NS)" if real_label == ML.NS
                else "Señal de PRIVACIÓN  (real: SD)")
        left = tk.Frame(inner, bg=TH.SURFACE_ALT)
        left.pack(side=tk.LEFT)
        tk.Label(left, text=name, font=(TH.FAMILY, 12, "bold"),
                 bg=TH.SURFACE_ALT, fg=TH.TEXT).pack(anchor="w")
        txt = ("n/d" if proba_sd is None or np.isnan(proba_sd)
               else f"P(SD) = {proba_sd:.0%}")
        tk.Label(left, text=txt, font=TH.F_BODY, bg=TH.SURFACE_ALT,
                 fg=TH.TEXT_MUTED).pack(anchor="w", pady=(3, 0))
        pred_txt = ("Descansado" if pred == ML.NS else
                    "Privado de sueño" if pred == ML.SD else "n/d")
        if correct:
            bg, fg, mark = TH.SUCCESS_BG, TH.SUCCESS, "✓ correcto"
        elif correct is False:
            bg, fg, mark = TH.DANGER_BG, TH.DANGER, "✗ incorrecto"
        else:
            bg, fg, mark = TH.SURFACE, TH.TEXT_MUTED, "—"
        rt = tk.Frame(inner, bg=TH.SURFACE_ALT)
        rt.pack(side=tk.RIGHT)
        tk.Label(rt, text=f"Predicción: {pred_txt}",
                 font=(TH.FAMILY, 13, "bold"), bg=TH.SURFACE_ALT,
                 fg=TH.TEXT).pack(anchor="e")
        tk.Label(rt, text=mark, font=TH.F_BTN, padx=12, pady=4, bg=bg,
                 fg=fg).pack(anchor="e", pady=(4, 0))

    def refresh(self, *_):
        r = self.app.ml_results
        if r is None:
            return
        for w in self.rows.winfo_children():
            w.destroy()
        ok = int(r.predictions["correct"].sum())
        ntot = int(r.predictions["correct"].notna().sum())
        acc = ok / ntot if ntot else 0.0
        self.total.config(
            text=f"Aciertos totales del modelo:  {ok}/{ntot}  ({acc:.0%})")
        sub = self.app.current_subject
        pred = r.predictions
        g = pred[pred["subject"] == sub]
        if g.empty:
            tk.Label(self.rows, text="Sin datos para este sujeto.",
                     font=TH.F_BODY, bg=TH.SURFACE, fg=TH.TEXT_MUTED).pack(
                anchor="w")
            return
        for cond in (ML.NS, ML.SD):
            gr = g[g["condition"] == cond]
            if gr.empty:
                continue
            row = gr.iloc[0]
            self._row(cond, float(row["proba_sd"]), row["pred"],
                      bool(row["correct"]))
